#ifndef __DELAY_H_
#define __DELAY_H_

#include "ht32_cm0plus_misc.h"



void delay_ms(u32 ms);//����
void delay_us(u32 us);//΢��



#endif

