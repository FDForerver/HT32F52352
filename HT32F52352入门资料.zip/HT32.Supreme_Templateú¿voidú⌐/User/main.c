#include "ht32.h"
#include "usart.h"
#include "Delay.h"


static void delay(u32 nCount)
{
  vu32 i;
  for (i = 0; i < 10000 * nCount; i++){}
}


int main(void)
{
	
	USART0_Configuration();
	while(1)
	{
		UsartPrintf(HT_USART0, "You are nice!");
		delay(100);
	}
	
}
