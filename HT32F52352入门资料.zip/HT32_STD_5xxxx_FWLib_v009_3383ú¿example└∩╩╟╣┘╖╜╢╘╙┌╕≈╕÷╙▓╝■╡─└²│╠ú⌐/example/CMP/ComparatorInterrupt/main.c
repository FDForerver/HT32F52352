/*********************************************************************************************************//**
 * @file    CMP/ComparatorInterrupt/main.c
 * @version $Rev:: 1391         $
 * @date    $Date:: 2017-06-20 #$
 * @brief   Main program.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup CMP_Examples CMP
  * @{
  */

/** @addtogroup ComparatorInterrupt
  * @{
  */
/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  ***********************************************************************************************************/
int main(void)
{
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  CMP_InitTypeDef CMP_IniStruct;

  /* Enable AFIO, GPTM0, CMP                                                                                */
  CKCUClock.Bit.AFIO  = 1;
  CKCUClock.Bit.CMP   = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);

  /* LED1 Init                                                                                              */
  HT32F_DVB_LEDInit(HT_LED1);
  /* Config CMP0 pins function                                                                              */
  AFIO_GPxConfig(HTCFG_CP_AFIO_PORT, HTCFG_CP_AFIO_PIN , AFIO_MODE_3);

  /**********************************************
  Set CMP0 Control Reg:
    1. Setting comparator internal 6-bit reference voltage scaler output.
    2. Setting 6-bit scaler reference voltage source comes from VDDA.
    3. Enable 6-bit scaler for comparator voltage reference.
    4. Enable 6-bit scaler output to CN pin.
    5. Setting CVREF = 16V.
  *********************************************/
  /* Reset CMP Struct                                                                                       */
  CMP_UnprotectConfig(HT_CMP0);
  CMP_StructInit(&CMP_IniStruct);
  CMP_IniStruct.CMP_InvInputSelection = CMP_SCALER_CN_IN;
  CMP_IniStruct.CMP_ScalerSource      = CMP_SCALER_SRC_VDDA;
  CMP_IniStruct.CMP_ScalerEnable      = CMP_SCALER_ENABLE;
  CMP_IniStruct.CMP_ScalerOutputBuf   = CMP_SCALER_OBUF_ENABLE;
  CMP_Init(HT_CMP0,&CMP_IniStruct);
  /* CVREF = 31 * (VDDA-VSSA)/63 = 31 * 3.3/63 = 1.6v                                                       */
  CMP_SetScalerValue(HT_CMP0, 31);

  /**********************************************
  Setting CMP0's Interrupt
  *********************************************/
  CMP_IntConfig(HT_CMP0, CMP_INT_RE | CMP_INT_FE, ENABLE);
  /*Setting the specified CMP rising/falling edge detection.                                                */
  CMP_EdgeDetectConfig(HT_CMP0, CMP_RE_Detect | CMP_FE_Detect, ENABLE);
  NVIC_EnableIRQ(COMP_IRQn);

  /*Enable CMP0                                                                                             */
  CMP_UnprotectConfig(HT_CMP0);
  CMP_Cmd(HT_CMP0, ENABLE);
  /* Infinite loop                                                                                          */
  while (1)
  ;

}
#if (HT32_LIB_DEBUG == 1)
/*********************************************************************************************************//**
  * @brief  Report both the error name of the source file and the source line number.
  * @param  filename: pointer to the source file name.
  * @param  uline: error line source number.
  * @retval None
  ***********************************************************************************************************/
void assert_error(u8* filename, u32 uline)
{
  /*
     This function is called by IP library that the invalid parameters has been passed to the library API.
     Debug message can be added here.
     Example: printf("Parameter Error: file %s on line %d\r\n", filename, uline);
  */

  while (1)
  {
  }
}
#endif


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
