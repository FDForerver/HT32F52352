/*********************************************************************************************************//**
 * @file    ADC/Two_Group_MaxCH/ht32_board_config.h
 * @version $Rev:: 3160         $
 * @date    $Date:: 2018-10-23 #$
 * @brief   The header file of board configuration.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __HT32_BOARD_CONFIG_H
#define __HT32_BOARD_CONFIG_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Settings ------------------------------------------------------------------------------------------------*/
#if (LIBCFG_ADC_CH8_11 == 0)
  #error "This example code does not apply to the chip you selected."
#endif

#if (LIBCFG_NO_ADC == 1)
  #error "This example code does not apply to the chip you selected."
#endif

#if (LIBCFG_ADC_CH12_15 == 1)
  #define HTCFG_CH0_GPIO_ID               (GPIO_PA)
  #define HTCFG_CH1_GPIO_ID               (GPIO_PA)
  #define HTCFG_CH2_GPIO_ID               (GPIO_PA)
  #define HTCFG_CH3_GPIO_ID               (GPIO_PA)
  #define HTCFG_CH4_GPIO_ID               (GPIO_PA)
  #define HTCFG_CH5_GPIO_ID               (GPIO_PA)
  #define HTCFG_CH6_GPIO_ID               (GPIO_PA)
  #define HTCFG_CH7_GPIO_ID               (GPIO_PA)
  #define HTCFG_CH8_GPIO_ID               (GPIO_PC)
  #define HTCFG_CH9_GPIO_ID               (GPIO_PC)
  #define HTCFG_CH10_GPIO_ID              (GPIO_PC)
  #define HTCFG_CH11_GPIO_ID              (GPIO_PC)

  #define HTCFG_CH0_AFIO_PIN              (AFIO_PIN_0)
  #define HTCFG_CH1_AFIO_PIN              (AFIO_PIN_1)
  #define HTCFG_CH2_AFIO_PIN              (AFIO_PIN_2)
  #define HTCFG_CH3_AFIO_PIN              (AFIO_PIN_3)
  #define HTCFG_CH4_AFIO_PIN              (AFIO_PIN_4)
  #define HTCFG_CH5_AFIO_PIN              (AFIO_PIN_5)
  #define HTCFG_CH6_AFIO_PIN              (AFIO_PIN_6)
  #define HTCFG_CH7_AFIO_PIN              (AFIO_PIN_7)
  #define HTCFG_CH8_AFIO_PIN              (AFIO_PIN_4)
  #define HTCFG_CH9_AFIO_PIN              (AFIO_PIN_5)
  #define HTCFG_CH10_AFIO_PIN             (AFIO_PIN_8)
  #define HTCFG_CH11_AFIO_PIN             (AFIO_PIN_9)
#else
  #define HTCFG_CH0_GPIO_ID               (GPIO_PC)
  #define HTCFG_CH1_GPIO_ID               (GPIO_PB)
  #define HTCFG_CH2_GPIO_ID               (GPIO_PB)
  #define HTCFG_CH3_GPIO_ID               (GPIO_PB)
  #define HTCFG_CH4_GPIO_ID               (GPIO_PA)
  #define HTCFG_CH5_GPIO_ID               (GPIO_PA)
  #define HTCFG_CH6_GPIO_ID               (GPIO_PA)
  #define HTCFG_CH7_GPIO_ID               (GPIO_PA)
  #define HTCFG_CH8_GPIO_ID               (GPIO_PA)
  #define HTCFG_CH9_GPIO_ID               (GPIO_PA)
  #define HTCFG_CH10_GPIO_ID              (GPIO_PA)
  #define HTCFG_CH11_GPIO_ID              (GPIO_PA)

  #define HTCFG_CH0_AFIO_PIN              (AFIO_PIN_3)
  #define HTCFG_CH1_AFIO_PIN              (AFIO_PIN_6)
  #define HTCFG_CH2_AFIO_PIN              (AFIO_PIN_7)
  #define HTCFG_CH3_AFIO_PIN              (AFIO_PIN_8)
  #define HTCFG_CH4_AFIO_PIN              (AFIO_PIN_0)
  #define HTCFG_CH5_AFIO_PIN              (AFIO_PIN_1)
  #define HTCFG_CH6_AFIO_PIN              (AFIO_PIN_2)
  #define HTCFG_CH7_AFIO_PIN              (AFIO_PIN_3)
  #define HTCFG_CH8_AFIO_PIN              (AFIO_PIN_4)
  #define HTCFG_CH9_AFIO_PIN              (AFIO_PIN_5)
  #define HTCFG_CH10_AFIO_PIN             (AFIO_PIN_6)
  #define HTCFG_CH11_AFIO_PIN             (AFIO_PIN_7)
#endif
#ifdef __cplusplus
}
#endif

#endif
