#ifndef _BUZZER_H_
#define _BUZZER_H_

#include "ht32f5xxxx_ckcu.h"
#include "ht32f5xxxx_gpio.h"



//�˿ںŶ���
#define HT_GPIO_Buzzer_PORT HT_GPIOD
//Buzzer���Ŷ���
#define HT_GPIO_Buzzer_PIN  GPIO_PIN_0

//Buzzer �궨�忪�͹�
#define Buzzer_ON() 	GPIO_WriteOutBits(HT_GPIO_Buzzer_PORT,HT_GPIO_Buzzer_PIN,RESET)
#define Buzzer_OFF()  GPIO_WriteOutBits(HT_GPIO_Buzzer_PORT,HT_GPIO_Buzzer_PIN,SET)
void Buzzer_Init(void);
void Buzzer_Running(void);

#endif
