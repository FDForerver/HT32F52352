#include "ht32.h"
#include "ht32_board.h"
#include "led.h"
#include "delay.h"
#include "uart.h"
#include "time.h"

/******************TH32 ��ʱ��GPTM��·�������*******************
Author:С��

Date:2022-4-28
***************************************************************/
int main()
{
	Led_Init();
	USARTx_Init();
	GPTM_PWM_init();
	Servo_Run(45);
	Servo_Run2(45);
	Servo_Run3(45);
	Servo_Run4(45);
	
	printf("---------pwm Test------\n");
	while(1)
	{
		Servo_Run(0);
		delay_ms(1000);
		Servo_Run(45);
		delay_ms(1000);
		
		Servo_Run2(0);
		delay_ms(1000);
		Servo_Run2(45);
		delay_ms(1000);
		
		Servo_Run3(0);
		delay_ms(1000);
		Servo_Run3(45);
		delay_ms(1000);
		
		Servo_Run4(0);
		delay_ms(500);
		Servo_Run4(45);
		delay_ms(500);
	}
}



