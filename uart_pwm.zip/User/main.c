#include "ht32.h"
#include "ht32_board.h"
#include "led.h"
#include "delay.h"
#include "uart.h"
#include "time.h"

/******************TH32 ����GPTM��·�������*******************
Author:С��

Date:2022-4-28
***************************************************************/
int main()
{
	Led_Init();
	Uart_Init();
	GPTM_PWM_init();
	Servo_Run(45);
	Servo_Run2(45);
	Servo_Run3(45);
	Servo_Run4(45);
	printf("---------pwm Test------\n");
	while(1)
	{
		
	}
}


//ʹ�ô���1 �������ݵĽ���
void COM1_IRQHandler(void)
{
	uint8_t data = 0;
	if( USART_GetFlagStatus(COM1_PORT, USART_FLAG_RXDR) )
	{
		data = USART_ReceiveData(COM1_PORT);
		//printf("data = %c\n",data);
		if(data == '1')
		{	
			Servo_Run(0);
			printf("servo1 open\n");
		}
		else if(data == '2')
		{	
			Servo_Run(45);
			printf("servo1 close\n");
		}
		else if(data == '3')
		{	
			Servo_Run2(0);
			printf("servo2 open\n");
		}
		else if(data == '4')
		{	
			Servo_Run2(45);
			printf("servo2 close\n");
		}
		/* ���Լ����������ƹ��� */
			USART_ClearFlag(COM1_PORT, USART_FLAG_RSADD);
	}
}
