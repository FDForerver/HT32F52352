#include "ht32.h"
#include "ht32_board.h"
#include "led.h"
#include "delay.h"
#include "uart.h"
#include "key.h"
#include "time.h"

/**********************TH32 �ⲿ�жϿ��ƶ��**********************
Author:С��

Date:2022-4-29
****************************************************************/


int main()
{
	uint8_t keynum = 0;
	Led_Init();
	USARTx_Init();
	GPTM_PWM_init();
	Key_Init();
	Servo_Run(45);
	Servo_Run2(45);
	Servo_Run3(45);
	Servo_Run4(45);
	printf("------key test------\n");
	while(1)
	{
		

	}
}

//ϸ�ں����ֲ�����key_stat ����Ϊstatic����Ҫ��Ȼ�����ڶ����޷�Ӧ

void EXTI4_15_IRQHandler(void)
{
 		static uint8_t key_stat = 0; //����״̬
    if(key_stat == 0)
		{
			key_stat = 1;
			LED1_ON();
			Servo_Run(0);
		}
		else if(key_stat == 1)
		{
			key_stat = 0;
			LED1_OFF();
			Servo_Run(45);
		}
		EXTI_ClearEdgeFlag(EXTI_CHANNEL_4);
}

void EXTI2_3_IRQHandler(void)
{
	static uint8_t key_stat = 0; //����״̬ 
	if(key_stat == 0)
		{
			key_stat = 1;
			LED2_ON();
			Servo_Run2(0);
		}
		else if(key_stat == 1)
		{
			key_stat = 0;
			LED2_OFF();
			Servo_Run2(45);
		}
		EXTI_ClearEdgeFlag(EXTI_CHANNEL_2);
}



void EXTI0_1_IRQHandler(void)
{
		static uint8_t key_stat = 0;
		if(key_stat == 0)
		{
			key_stat = 1;
			LED2_ON();
			Servo_Run3(0);
		}
		else if(key_stat == 1)
		{
			key_stat = 0;
			LED2_OFF();
			Servo_Run3(45);
		}
		EXTI_ClearEdgeFlag(EXTI_CHANNEL_0);
}